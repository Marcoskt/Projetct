Projeto feito em ambiente Windows 10.
Vers�o do java 8.

INSTRU��ES PARA USO

Abra o arquivo abrir.bat, esse arquivo vai executar o Projeto_SO.jar que � o projeto feito em java que contem o problema proposto.

Obs: Caso aparecer "O Windows protegeu o computador" clique em "Mais informa��es" e "Executar mesmo assim".

ou se prefirir

Crie um projeto com nome de classe principal main.
Copie o codigo listado e cole.
Mude o caminho da cria��o do documento txt caso precise , no caso ela est� configurada para criar o documento em
um pen drive.
E depois � so executar.



O funcionamento do c�digo � garantido de forma que ele nunca escreve o mesmo texto duas vezes seguidas, ele
sempre alterna os textos das threads atrav�s da variavel de lock.